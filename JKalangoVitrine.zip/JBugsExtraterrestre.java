public class JBugsExtraterrestre extends Inimigo {
    public JBugsExtraterrestre(String nome, int vida, int perigo) {
        super(nome, vida, perigo);
    }
}