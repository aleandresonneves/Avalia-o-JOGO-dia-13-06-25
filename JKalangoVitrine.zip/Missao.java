public class Missao {
    private String descricao;
    private boolean completa;

    public Missao(String descricao) {
        this.descricao = descricao;
        this.completa = false;
    }

    public void concluir() {
        this.completa = true;
    }

    public String getStatus() {
        return completa ? "Missão concluída" : "Missão em andamento: " + descricao;
    }
}