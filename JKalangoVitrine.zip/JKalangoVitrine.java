import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JKalangoVitrine extends JFrame {
    private JTextArea historiaArea;
    private JButton avancarBtn;
    private int etapa = 0;

    private JKalango heroi;
    private JBugsExtraterrestre inimigo;

    public JKalangoVitrine() {
        setTitle("JKALANGO - A Vitrine do Fim do Mundo");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.black);

        heroi = new JKalango("JKalango", 100, 50);
        inimigo = new JBugsExtraterrestre("JBug Scorcher", 80, 40);

        historiaArea = new JTextArea();
        historiaArea.setEditable(false);
        historiaArea.setForeground(Color.GREEN);
        historiaArea.setBackground(Color.BLACK);
        historiaArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        historiaArea.setLineWrap(true);
        historiaArea.setWrapStyleWord(true);
        add(new JScrollPane(historiaArea), BorderLayout.CENTER);

        avancarBtn = new JButton("Avançar");
        avancarBtn.addActionListener(e -> avancarHistoria());
        add(avancarBtn, BorderLayout.SOUTH);

        mostrarIntroducao();
    }

    private void mostrarIntroducao() {
        historiaArea.setText("Ano 2187...\nApós o último inverno nuclear, a Terra caiu...\n");
    }

    private void avancarHistoria() {
        etapa++;
        switch (etapa) {
            case 1:
                historiaArea.append("\nNos escombros de uma civilização extinta, surge um herói solitário: " + heroi.getNome());
                break;
            case 2:
                historiaArea.append("\nEle ouve ruídos nos céus: os JBugs estão aqui.\nInimigo detectado: " + inimigo.getNome());
                break;
            case 3:
                historiaArea.append("\n" + heroi.getNome() + " prepara sua arma e ataca!\n");
                historiaArea.append(heroi.atacar(inimigo));
                break;
            case 4:
                historiaArea.append("\nA batalha está apenas começando...");
                avancarBtn.setEnabled(false);
                break;
        }
    }
}