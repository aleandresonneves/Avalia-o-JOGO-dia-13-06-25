public interface Atacavel {
    String atacar(EntidadeDoJogo alvo);
}