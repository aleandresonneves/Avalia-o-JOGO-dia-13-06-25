public class Personagem extends EntidadeDoJogo {
    protected int forca;

    public Personagem(String nome, int vida, int forca) {
        super(nome, vida);
        this.forca = forca;
    }

    @Override
    public String descrever() {
        return nome + " é um sobrevivente com " + vida + " de vida.";
    }
}