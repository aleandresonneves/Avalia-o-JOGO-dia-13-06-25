public abstract class EntidadeDoJogo {
    protected String nome;
    protected int vida;

    public EntidadeDoJogo(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public void receberDano(int dano) {
        this.vida -= dano;
    }

    public abstract String descrever();
}