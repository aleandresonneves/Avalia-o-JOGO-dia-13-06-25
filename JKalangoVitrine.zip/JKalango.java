public class JKalango extends Personagem implements Atacavel {
    public JKalango(String nome, int vida, int forca) {
        super(nome, vida, forca);
    }

    @Override
    public String atacar(EntidadeDoJogo alvo) {
        alvo.receberDano(forca);
        return nome + " ataca " + alvo.getNome() + " causando " + forca + " de dano.\n";
    }
}