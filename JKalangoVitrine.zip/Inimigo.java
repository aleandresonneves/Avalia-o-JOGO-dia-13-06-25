public class Inimigo extends EntidadeDoJogo {
    protected int perigo;

    public Inimigo(String nome, int vida, int perigo) {
        super(nome, vida);
        this.perigo = perigo;
    }

    @Override
    public String descrever() {
        return "Inimigo: " + nome + " - Ameaça: " + perigo;
    }
}